abstract class ProfileDataSource {
  Future<bool> signOut();
}
