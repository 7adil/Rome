abstract class HotelsDataSource {
  Future<dynamic> getHotels();
}
