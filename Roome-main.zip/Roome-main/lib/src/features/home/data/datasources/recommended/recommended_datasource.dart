abstract class RecommendedDataSource {
  Future<dynamic> getRecommendedMeHotels({required int userId});
}
