abstract class NearMeDataSource {
  Future<dynamic> getNearMeHotels({required int userId});
}
