abstract class SearchDatasource {
  Future<List<dynamic>> searchHotels({required String hotelName});
}
