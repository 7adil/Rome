abstract class RegularUseCases<Type, Params> {
  Type call(Params params);
}
