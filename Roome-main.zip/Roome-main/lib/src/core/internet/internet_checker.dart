abstract class InternetChecker {
  Future<bool> get isConnected;
}
