abstract class Failure {
  final String? failureMsg;

  const Failure({this.failureMsg});
}
